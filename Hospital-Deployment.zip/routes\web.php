<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return ['message' => 'Hospital Appointment Booking System API'];
});
